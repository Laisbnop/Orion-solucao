/* ==================================================================
   SCRIPT.JS — conecta a tela de login ao Flask
   Fábrica de Projetos | Grupo Orion x CygniAG
   ==================================================================

   ATENÇÃO: se o Flask estiver rodando numa porta diferente de 5000,
   troca aqui:
================================================================== */
const URL_API = "http://localhost:5000";

const telaLogin = document.getElementById("telaLogin");
const telaDashboard = document.getElementById("telaDashboard");
const loginForm = document.getElementById("loginForm");
const loginError = document.getElementById("loginError");
const btnEntrar = document.getElementById("btnEntrar");
const toggleSenha = document.getElementById("toggleSenha");

/* -------- mostrar/ocultar senha -------- */
toggleSenha.addEventListener("click", () => {
  const campoSenha = document.getElementById("senha");
  const ficaVisivel = campoSenha.type === "password";
  campoSenha.type = ficaVisivel ? "text" : "password";
  toggleSenha.textContent = ficaVisivel ? "ocultar" : "mostrar";
});

/* -------- envio do formulário de login -------- */
loginForm.addEventListener("submit", async (evento) => {
  evento.preventDefault();

  const usuario = document.getElementById("usuario").value.trim();
  const senha = document.getElementById("senha").value;

  loginError.hidden = true;
  btnEntrar.disabled = true;
  btnEntrar.textContent = "Entrando...";

  try {
    const resposta = await fetch(`${URL_API}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usuario, senha }),
    });

    const dados = await resposta.json();

    if (!dados.sucesso) {
      loginError.textContent = dados.motivo || "Usuário ou senha inválidos.";
      loginError.hidden = false;
      return;
    }

    mostrarDashboard(dados);

  } catch (erro) {
    loginError.textContent = "Não consegui falar com o servidor. Ele está rodando? (python3 app.py)";
    loginError.hidden = false;
  } finally {
    btnEntrar.disabled = false;
    btnEntrar.textContent = "Entrar";
  }
});

/* -------- sair, volta pra tela de login -------- */
document.getElementById("btnSair").addEventListener("click", () => {
  telaDashboard.hidden = true;
  telaLogin.style.display = "flex";
  loginForm.reset();
});

/* -------- monta a tela de dashboard com o que o Flask devolveu -------- */
function mostrarDashboard(dados) {
  telaLogin.style.display = "none";
  telaDashboard.hidden = false;

  const ehOrion = dados.papel === "orion";

  document.getElementById("avatarIniciais").textContent = dados.nome.charAt(0);
  document.getElementById("sidebarNome").textContent = dados.nome;
  document.getElementById("sidebarPapel").textContent = ehOrion ? "Colaborador Orion" : "Produtor";

  document.getElementById("tituloPagina").textContent = ehOrion
    ? "Todos os talhões"
    : `Talhões — ${dados.fazenda}`;
  document.getElementById("subtituloPagina").textContent = ehOrion
    ? "Visão de todos os produtores atendidos"
    : `Bem-vindo, ${dados.nome}`;

  document.getElementById("thProdutor").hidden = !ehOrion;

  const total = dados.aplicacoes.length;
  const ok = dados.aplicacoes.filter(a => a.status === "Dentro do esperado").length;
  const atencao = total - ok;

  document.getElementById("statTotal").textContent = total;
  document.getElementById("statOk").textContent = ok;
  document.getElementById("statAtencao").textContent = atencao;

  desenharGraficoRosca(ok, atencao);
  desenharGraficoBarras(dados.aplicacoes);

  const corpoTabela = document.getElementById("corpoTabela");
  corpoTabela.innerHTML = dados.aplicacoes.map(aplicacao => {
    const classeStatus = aplicacao.status === "Dentro do esperado" ? "badge--green" : "badge--orange";
    const colunaProdutor = ehOrion ? `<td>${aplicacao.produtor}</td>` : "";
    const motivoTexto = aplicacao.motivo && aplicacao.motivo.texto ? aplicacao.motivo.texto : "—";

    return `
      <tr>
        <td>${aplicacao.talhao}</td>
        ${colunaProdutor}
        <td>${formatarData(aplicacao.data)}</td>
        <td>${aplicacao.dose_prescrita} mL/ha</td>
        <td>${aplicacao.dose_aplicada} mL/ha</td>
        <td>${aplicacao.desvio_pct > 0 ? "+" : ""}${aplicacao.desvio_pct}%</td>
        <td><span class="badge ${classeStatus} badge-texto">${aplicacao.status}</span></td>
        <td style="font-size:12.5px; color:#4b5563; line-height:1.4;">${motivoTexto}</td>
      </tr>
    `;
  }).join("");
}

function formatarData(dataISO) {
  const [ano, mes, dia] = dataISO.split("-");
  return `${dia}/${mes}/${ano}`;
}

/* ==================================================================
   GRÁFICOS — SVG puro, sem dependência externa
   ================================================================== */

function desenharGraficoRosca(ok, atencao) {
  const total = ok + atencao;
  const raio = 50;
  const centro = 60;
  const espessura = 18;
  const circunferencia = 2 * Math.PI * raio;

  const fatiaOk = total > 0 ? (ok / total) * circunferencia : 0;
  const fatiaAtencao = total > 0 ? (atencao / total) * circunferencia : 0;

  const svg = `
    <svg width="120" height="120" viewBox="0 0 120 120">
      <circle cx="${centro}" cy="${centro}" r="${raio}" fill="none" stroke="#e5e3da" stroke-width="${espessura}"/>
      <circle cx="${centro}" cy="${centro}" r="${raio}" fill="none" stroke="#22c55e" stroke-width="${espessura}"
        stroke-dasharray="${fatiaOk} ${circunferencia - fatiaOk}"
        stroke-dashoffset="0" transform="rotate(-90 ${centro} ${centro})"/>
      <circle cx="${centro}" cy="${centro}" r="${raio}" fill="none" stroke="#f59e0b" stroke-width="${espessura}"
        stroke-dasharray="${fatiaAtencao} ${circunferencia - fatiaAtencao}"
        stroke-dashoffset="-${fatiaOk}" transform="rotate(-90 ${centro} ${centro})"/>
      <text x="${centro}" y="${centro}" text-anchor="middle" dominant-baseline="central" font-size="20" font-weight="700" fill="#1c1c1c">${total}</text>
    </svg>
    <div style="display:flex; gap:14px; justify-content:center; margin-top:8px; font-size:12px; color:#6b7280;">
      <span><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#22c55e;"></span> Dentro (${ok})</span>
      <span><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#f59e0b;"></span> Fora (${atencao})</span>
    </div>
  `;

  document.getElementById("graficoRosca").innerHTML = svg;
}

function desenharGraficoBarras(aplicacoes) {
  const largura = 380;
  const altura = 160;
  const margemEsquerda = 30;
  const margemInferior = 30;
  const larguraUtil = largura - margemEsquerda - 10;
  const alturaUtil = altura - margemInferior - 10;

  const maiorDesvio = Math.max(...aplicacoes.map(a => Math.abs(a.desvio_pct)), 10);
  const larguraBarra = Math.min(24, larguraUtil / aplicacoes.length - 6);
  const zeroY = 10 + alturaUtil / 2;

  let barras = "";
  aplicacoes.forEach((aplicacao, indice) => {
    const x = margemEsquerda + indice * (larguraUtil / aplicacoes.length) + 4;
    const alturaBarra = (Math.abs(aplicacao.desvio_pct) / maiorDesvio) * (alturaUtil / 2);
    const y = aplicacao.desvio_pct >= 0 ? zeroY - alturaBarra : zeroY;
    const cor = aplicacao.status === "Dentro do esperado" ? "#22c55e" : "#f59e0b";

    barras += `<rect x="${x}" y="${y}" width="${larguraBarra}" height="${Math.max(alturaBarra, 1)}" fill="${cor}" rx="2"/>`;
  });

  const svg = `
    <svg width="100%" viewBox="0 0 ${largura} ${altura}" style="max-width:380px;">
      <line x1="${margemEsquerda}" y1="${zeroY}" x2="${largura - 10}" y2="${zeroY}" stroke="#d8d6cd" stroke-width="1"/>
      ${barras}
      <text x="4" y="${zeroY}" font-size="10" fill="#6b7280" dominant-baseline="central">0%</text>
    </svg>
  `;

  document.getElementById("graficoBarras").innerHTML = svg;
}
