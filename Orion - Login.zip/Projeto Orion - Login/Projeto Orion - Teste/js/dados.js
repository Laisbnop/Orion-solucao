var USUARIOS = [
  { login: "produtor1", senha: "santaluzia123", papel: "produtor", nome: "Rafael Castanha", fazenda: "Fazenda Santa Luzia" },
  { login: "produtor2", senha: "boavista123", papel: "produtor", nome: "Letícia Correa", fazenda: "Fazenda Boa Vista" },
  { login: "produtor3", senha: "rioverde123", papel: "produtor", nome: "Renan Ferraroni", fazenda: "Fazenda Rio Verde" },
  { login: "agronomo1", senha: "orion123", papel: "orion", nome: "Camila Dias", fazenda: null },
  { login: "agronomo2", senha: "orion456", papel: "orion", nome: "Lais Bueno", fazenda: null }
];
